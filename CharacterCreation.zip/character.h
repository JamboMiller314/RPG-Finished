#ifndef __CHARACTER_h
#define __ CHARACTER_H

#include <iostream>
#include <string>
#include <vector>

class Character
{
public:
    Character();
    std::string askAncestry();
    std::string askName();
    std::string askClass();
    void askTraitsSetup();
    void printCharacterTraits() const;
   
   
private:
    std::string m_Name;
    int strength, dexterity, intelligence, endurance, wisdom;
    

    int readAbilityScore(const std::string& abilityName) const;
    bool validateAbilityScore(int score) const;
    void setAbilityScoreBonus(const std::string& selectedClass);
};
#endif //__CHARACTER_H