#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

#include "Character.h"












int main()
{
	Character character;

	while (true)
	{
		std::cout << "Welcome to character creation! \n\n";


		character.askAncestry();
		character.askClass();
		character.askName();
		character.askTraitsSetup();
		
		character.printCharacterTraits();

		std::cout << "Do you want to generate a new character? \n";
		char response;
		std::cin >> response;

		if (response == 'n' || response == 'N')
		{
			break;
		}

		
		
	}
	

	
	










	
	return 0;
}
